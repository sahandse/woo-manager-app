import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import '../../core/format/persian_digits.dart';
import '../../core/network/api_client.dart';
import 'order_detail_page.dart';

class OrdersPage extends StatefulWidget{const OrdersPage({super.key,required this.client});final ApiClient client;@override State<OrdersPage> createState()=>_OrdersPageState();}
class _OrdersPageState extends State<OrdersPage>{late Future<Map<String,dynamic>> future;final search=TextEditingController();Timer? timer;String status='',period='all',payment='',shipping='';final selected=<int>{};bool bulkBusy=false;
static const statuses={'':'همه','pending':'در انتظار پرداخت','processing':'در حال انجام','on-hold':'در انتظار بررسی','completed':'تکمیل‌شده','cancelled':'لغوشده','refunded':'بازپرداخت‌شده','failed':'ناموفق'};
@override void initState(){super.initState();load();}@override void dispose(){timer?.cancel();search.dispose();super.dispose();}
Map<String,String> dates(){if(period=='all')return{};final now=DateTime.now(),days=int.parse(period);String f(DateTime d)=>'${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';return{'from':f(now.subtract(Duration(days:days))),'to':f(now)};}
void load(){final d=dates();setState(()=>future=widget.client.ordersResult(status:status,search:search.text.trim(),paymentMethod:payment,shippingMethod:shipping,dateFrom:d['from']??'',dateTo:d['to']??''));}
void delayed(String _){timer?.cancel();timer=Timer(const Duration(milliseconds:450),load);}
String error(Object e){if(e is DioException){final d=e.response?.data;if(d is Map&&d['message']!=null)return '${d['message']}';return 'ارتباط با فروشگاه برقرار نشد؛ عملیات بعد از اتصال دوباره قابل تکرار است.';}return e.toString().replaceFirst('FormatException: ','');}
Future<void> bulk()async{String value='processing';final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setModal)=>AlertDialog(title:Text('تغییر وضعیت ${selected.length.fa} سفارش'),content:DropdownButtonFormField(value:value,items:statuses.entries.where((e)=>e.key.isNotEmpty).map((e)=>DropdownMenuItem(value:e.key,child:Text(e.value))).toList(),onChanged:(v)=>setModal(()=>value=v!)),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('انصراف')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('اعمال'))])));if(ok!=true)return;setState(()=>bulkBusy=true);try{final r=await widget.client.bulkOrderStatus(selected.toList(),value);if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${((r['updated'] as List?) ?? []).length.fa} سفارش به‌روزرسانی شد.')));selected.clear();load();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(error(e))));}finally{if(mounted)setState(()=>bulkBusy=false);}}
Future<void> filters()async{var p=period;final payC=TextEditingController(text:payment),shipC=TextEditingController(text:shipping);final ok=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,builder:(c)=>StatefulBuilder(builder:(c,setModal)=>Padding(padding:EdgeInsets.fromLTRB(20,20,20,20+MediaQuery.viewInsetsOf(c).bottom),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text('فیلتر سفارش‌ها',style:Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:16),DropdownButtonFormField(value:p,decoration:const InputDecoration(labelText:'بازه تاریخ'),items:const [DropdownMenuItem(value:'all',child:Text('همه تاریخ‌ها')),DropdownMenuItem(value:'1',child:Text('امروز')),DropdownMenuItem(value:'7',child:Text('۷ روز اخیر')),DropdownMenuItem(value:'30',child:Text('۳۰ روز اخیر')),DropdownMenuItem(value:'90',child:Text('۹۰ روز اخیر'))],onChanged:(v)=>setModal(()=>p=v!)),const SizedBox(height:10),TextField(controller:payC,decoration:const InputDecoration(labelText:'شناسه روش پرداخت (اختیاری)')),const SizedBox(height:10),TextField(controller:shipC,decoration:const InputDecoration(labelText:'نام روش ارسال (اختیاری)')),const SizedBox(height:16),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('اعمال فیلتر'))]))));if(ok==true){period=p;payment=payC.text.trim();shipping=shipC.text.trim();load();}payC.dispose();shipC.dispose();}
@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text(selected.isEmpty ? 'سفارش‌ها' : '${selected.length.fa} انتخاب'),
      actions: [
        if (selected.isNotEmpty)
          IconButton(onPressed: bulkBusy ? null : bulk, icon: const Icon(Icons.drive_file_rename_outline_rounded)),
        IconButton(
          onPressed: filters,
          icon: Badge(
            isLabelVisible: period != 'all' || payment.isNotEmpty || shipping.isNotEmpty,
            child: const Icon(Icons.filter_alt_outlined),
          ),
        ),
        IconButton(onPressed: load, icon: const Icon(Icons.refresh_rounded)),
      ],
    ),
    body: Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: TextField(
            controller: search,
            onChanged: delayed,
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search_rounded),
              hintText: 'شماره، نام یا موبایل مشتری',
            ),
          ),
        ),
        SizedBox(
          height: 58,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            scrollDirection: Axis.horizontal,
            children: statuses.entries.map((e) => Padding(
              padding: const EdgeInsets.only(left: 8),
              child: ChoiceChip(
                label: Text(e.value),
                selected: status == e.key,
                onSelected: (_) { status = e.key; selected.clear(); load(); },
              ),
            )).toList(),
          ),
        ),
        if (bulkBusy) const LinearProgressIndicator(),
        Expanded(
          child: RefreshIndicator(
            onRefresh: () async => load(),
            child: FutureBuilder<Map<String, dynamic>>(
              future: future,
              builder: (context, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (s.hasError) {
                  return ListView(children: [
                    const SizedBox(height: 110),
                    const Icon(Icons.cloud_off_rounded, size: 54),
                    Padding(padding: const EdgeInsets.all(24), child: Text(error(s.error!), textAlign: TextAlign.center)),
                    Center(child: FilledButton.icon(onPressed: load, icon: const Icon(Icons.refresh), label: const Text('تلاش دوباره'))),
                  ]);
                }
                final result = s.data ?? <String, dynamic>{};
                final items = (result['items'] as List?) ?? [];
                if (items.isEmpty) {
                  return ListView(
                    padding: const EdgeInsets.all(24),
                    children: [
                      const SizedBox(height: 80),
                      const Icon(Icons.receipt_long_outlined, size: 56),
                      const SizedBox(height: 12),
                      const Text('سفارشی با این فیلتر دریافت نشد.', textAlign: TextAlign.center),
                      Text('تعداد کل فروشگاه: ${(result['store_total'] ?? 0).fa}', textAlign: TextAlign.center),
                    ],
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final o = Map<String, dynamic>.from(items[i] as Map);
                    final id = (o['id'] as num).toInt();
                    final checked = selected.contains(id);
                    void toggle() => setState(() => checked ? selected.remove(id) : selected.add(id));
                    return Card(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(22),
                        onLongPress: toggle,
                        onTap: () {
                          if (selected.isNotEmpty) {
                            toggle();
                          } else {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => OrderDetailPage(orderId: id, client: widget.client))).then((_) => load());
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(children: [
                            Checkbox(value: checked, onChanged: (_) => toggle()),
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(14)),
                              child: const Icon(Icons.receipt_long_rounded),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text('سفارش ${id.fa}', style: const TextStyle(fontWeight: FontWeight.w800)),
                                Text('${o['customer']?.toString().trim().isNotEmpty == true ? o['customer'] : 'مهمان'} • ${statuses[o['status']] ?? o['status']}'),
                                if ('${o['phone'] ?? ''}'.isNotEmpty) Text('${o['phone']}'.fa),
                                Text('${o['total'].fa} ${o['currency'] ?? ''}', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w800)),
                              ]),
                            ),
                            const Icon(Icons.chevron_left_rounded),
                          ]),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ],
    ),
  );
}
}
