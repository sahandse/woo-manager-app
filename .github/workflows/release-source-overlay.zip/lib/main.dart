import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/theme_controller.dart';
import 'features/connection/bootstrap_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ThemeController.load();
  runApp(const WooManagerApp());
}

class WooManagerApp extends StatelessWidget {
  const WooManagerApp({super.key});
  @override
  Widget build(BuildContext context)=>ValueListenableBuilder<ThemeMode>(
    valueListenable:ThemeController.mode,
    builder:(context,mode,_)=>ValueListenableBuilder<String>(valueListenable:ThemeController.accent,builder:(context,accent,_)=>MaterialApp(
      debugShowCheckedModeBanner:false,
      title:'مدیر فروشگاه',
      theme:AppTheme.light(accent),
      darkTheme:AppTheme.dark(accent),
      themeMode:mode,
      locale:const Locale('fa'),
      builder:(context,child)=>Directionality(textDirection:TextDirection.rtl,child:child!),
      home:const BootstrapPage(),
    )),
  );
}
