import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

abstract final class ThemeController {
  static const _storage = FlutterSecureStorage();
  static final mode=ValueNotifier<ThemeMode>(ThemeMode.light);
  static final accent=ValueNotifier<String>('emerald');
  static Future<void> load() async {
    await set(await _storage.read(key:'theme_mode')??'light',persist:false);
    await setAccent(await _storage.read(key:'theme_accent')??'emerald',persist:false);
  }
  static Future<void> set(String value,{bool persist=true}) async {
    mode.value=switch(value){'dark'=>ThemeMode.dark,'system'=>ThemeMode.system,_=>ThemeMode.light};
    if(persist)await _storage.write(key:'theme_mode',value:value);
  }
  static Future<void> setAccent(String value,{bool persist=true})async{
    const allowed={'emerald','blue','violet','rose','amber'};
    accent.value=allowed.contains(value)?value:'emerald';
    if(persist)await _storage.write(key:'theme_accent',value:accent.value);
  }
  static Future<void> toggle()=>set(mode.value==ThemeMode.dark?'light':'dark');
  static String get value=>switch(mode.value){ThemeMode.dark=>'dark',ThemeMode.light=>'light',_=>'system'};
}
