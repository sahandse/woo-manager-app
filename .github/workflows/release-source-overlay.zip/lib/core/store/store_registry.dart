import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

abstract final class StoreRegistry {
  static const _storage=FlutterSecureStorage(),_key='connected_stores_v1';
  static Future<List<Map<String,dynamic>>> all()async{final raw=await _storage.read(key:_key);if(raw==null)return [];try{return (jsonDecode(raw) as List).map((e)=>Map<String,dynamic>.from(e as Map)).toList();}catch(_){return [];}}
  static Future<void> upsert({required String url,required String token,required String name})async{final stores=await all();stores.removeWhere((s)=>s['url']==url);stores.insert(0,{'url':url,'token':token,'name':name});await _storage.write(key:_key,value:jsonEncode(stores));await activate(stores.first);}
  static Future<void> activate(Map<String,dynamic> store)async{await _storage.write(key:'site_url',value:store['url'].toString());await _storage.write(key:'token',value:store['token'].toString());await _storage.write(key:'store_name',value:store['name'].toString());}
  static Future<void> remove(String url)async{final stores=await all()..removeWhere((s)=>s['url']==url);await _storage.write(key:_key,value:jsonEncode(stores));}
}
