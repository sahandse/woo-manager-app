import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

abstract final class OfflineQueue {
  static const _storage=FlutterSecureStorage();
  static const _key='offline_mutations_v1';
  static Future<List<Map<String,dynamic>>> all()async{
    final raw=await _storage.read(key:_key);if(raw==null||raw.isEmpty)return [];
    try{return (jsonDecode(raw) as List).map((e)=>Map<String,dynamic>.from(e as Map)).toList();}catch(_){return [];}
  }
  static Future<void> add(Map<String,dynamic> item)async{final items=await all();items.add({...item,'created_at':DateTime.now().toIso8601String()});await _storage.write(key:_key,value:jsonEncode(items.take(100).toList()));}
  static Future<void> replace(List<Map<String,dynamic>> items)=>_storage.write(key:_key,value:jsonEncode(items));
}
